<?php
class Router {
    private $routes = [];

    public function get($uri, $action) {
        $this->routes['GET'][$uri] = $action;
    }

    public function post($uri, $action) {
        $this->routes['POST'][$uri] = $action;
    }

    public function run() {
        $method = $_SERVER['REQUEST_METHOD'];

        // FIX: nettoyer le path
        $path = isset($_GET['url']) 
            ? trim(str_replace(["\n", "\r"], '', $_GET['url']), '/') 
            : '';

        $action = $this->routes[$method][$path] ?? null;

        if (!$action) {
            header('HTTP/1.1 404 Not Found');
            echo json_encode(['error' => 'Route not found', 'path' => $path]);
            return;
        }

        list($controllerName, $methodName) = explode('@', $action);
        $controllerFile = __DIR__ . "/../app/controllers/{$controllerName}.php";

        require_once $controllerFile;
        $controller = new $controllerName();
        $controller->$methodName();
    }
}
