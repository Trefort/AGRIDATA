-- Database and tables for Agridata
CREATE DATABASE IF NOT EXISTS agridata CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE agridata;

-- users
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','farmer') DEFAULT 'farmer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- parcelles
CREATE TABLE IF NOT EXISTS parcelles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  name VARCHAR(150) NOT NULL,
  superficie DECIMAL(10,2) NOT NULL,
  localisation VARCHAR(255),
  type_sol VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- cultures
CREATE TABLE IF NOT EXISTS cultures (
  id INT AUTO_INCREMENT PRIMARY KEY,
  parcelle_id INT NOT NULL,
  type_culture VARCHAR(150) NOT NULL,
  variete VARCHAR(150),
  date_plantation DATE,
  date_recolte_prevue DATE,
  etat VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (parcelle_id) REFERENCES parcelles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- activites
CREATE TABLE IF NOT EXISTS activites (
  id INT AUTO_INCREMENT PRIMARY KEY,
  culture_id INT NOT NULL,
  type_activite VARCHAR(150) NOT NULL,
  description TEXT,
  date_activite DATE NOT NULL,
  cout DECIMAL(10,2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (culture_id) REFERENCES cultures(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- meteo
CREATE TABLE IF NOT EXISTS meteo (
  id INT AUTO_INCREMENT PRIMARY KEY,
  parcelle_id INT,
  temperature DECIMAL(5,2),
  humidite DECIMAL(5,2),
  pluie_mm DECIMAL(7,2),
  vent DECIMAL(5,2),
  date DATE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (parcelle_id) REFERENCES parcelles(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- rapports
CREATE TABLE IF NOT EXISTS rapports (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  titre VARCHAR(255) NOT NULL,
  contenu TEXT NOT NULL,
  date_generation DATE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
