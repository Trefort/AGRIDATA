<?php
// Define routes. Use ?url=... in requests (e.g. public/index.php?url=parcelles )
// Users
$router->get('users', 'UserController@index');
$router->get('users/show', 'UserController@show'); // expects ?id=
$router->post('users/create', 'UserController@store');
$router->post('users/update', 'UserController@update'); // expects id in POST or json
$router->post('users/delete', 'UserController@delete'); // expects ?id=

// Parcelles
$router->get('parcelles', 'ParcelleController@index');
$router->get('parcelles/show', 'ParcelleController@show'); // ?id=
$router->post('parcelles/create', 'ParcelleController@store');
$router->post('parcelles/update', 'ParcelleController@update'); // id in payload or ?id=
$router->post('parcelles/delete', 'ParcelleController@delete'); // ?id=

// Cultures
$router->get('cultures', 'CultureController@index');
$router->get('cultures/show', 'CultureController@show');
$router->post('cultures/create', 'CultureController@store');
$router->post('cultures/update', 'CultureController@update');
$router->post('cultures/delete', 'CultureController@delete');

// Activites
$router->get('activites', 'ActiviteController@index');
$router->get('activites/show', 'ActiviteController@show');
$router->post('activites/create', 'ActiviteController@store');
$router->post('activites/update', 'ActiviteController@update');
$router->post('activites/delete', 'ActiviteController@delete');

// Meteo
$router->get('meteo', 'MeteoController@index');
$router->get('meteo/show', 'MeteoController@show');
$router->post('meteo/create', 'MeteoController@store');
$router->post('meteo/delete', 'MeteoController@delete');

// Rapports
$router->get('rapports', 'RapportController@index');
$router->get('rapports/show', 'RapportController@show');
$router->post('rapports/create', 'RapportController@store');
$router->post('rapports/delete', 'RapportController@delete');