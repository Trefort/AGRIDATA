Agridata - Backend (PHP + MySQL)
Structure: simple MVC with a small Router.

How to use:
1. Place this project inside your WAMP www folder: C:\wamp64\www\agridata
2. Import the SQL: sql/create_tables.sql into phpMyAdmin to create the database and tables.
3. In config/database.php update DB credentials if necessary.
4. Access the API by visiting (example):
   http://localhost/agridata/public/index.php?url=parcelles

Routes are defined in routes/web.php. Use ?url=... and optional ?id=... for show/update/delete.

Examples:
GET list of parcelles:  GET public/index.php?url=parcelles
GET single parcelle:    GET public/index.php?url=parcelles/show&id=1
Create parcelle:        POST public/index.php?url=parcelles/create (JSON body)
Update parcelle:        POST public/index.php?url=parcelles/update&id=1 (JSON body)
Delete parcelle:        POST public/index.php?url=parcelles/delete&id=1
