<?php
require_once __DIR__ . '/../../config/database.php';

class Culture {
    private $conn;
    private $table = 'cultures';

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    public function getAll() {
        $stmt = $this->conn->prepare("SELECT * FROM cultures ORDER BY date_plantation DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find($id) {
        $stmt = $this->conn->prepare("SELECT * FROM cultures WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create($data) {
        $stmt = $this->conn->prepare("INSERT INTO cultures (parcelle_id, type_culture, variete, date_plantation, date_recolte_prevue, etat) VALUES (?, ?, ?, ?, ?, ?)");
        return $stmt->execute([$data['parcelle_id'], $data['type_culture'], $data['variete'], $data['date_plantation'], $data['date_recolte_prevue'], $data['etat']]);
    }

    public function update($id, $data) {
        $stmt = $this->conn->prepare("UPDATE cultures SET type_culture = ?, variete = ?, date_plantation = ?, date_recolte_prevue = ?, etat = ? WHERE id = ?");
        return $stmt->execute([$data['type_culture'], $data['variete'], $data['date_plantation'], $data['date_recolte_prevue'], $data['etat'], $id]);
    }

    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM cultures WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
?>