<?php
require_once __DIR__ . '/../../config/database.php';

class Activite {
    private $conn;
    private $table = 'activites';

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    public function getAll() {
        $stmt = $this->conn->prepare("SELECT * FROM activites ORDER BY date_activite DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find($id) {
        $stmt = $this->conn->prepare("SELECT * FROM activites WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create($data) {
        $stmt = $this->conn->prepare("INSERT INTO activites (culture_id, type_activite, description, date_activite, cout) VALUES (?, ?, ?, ?, ?)");
        return $stmt->execute([$data['culture_id'], $data['type_activite'], $data['description'], $data['date_activite'], $data['cout']]);
    }

    public function update($id, $data) {
        $stmt = $this->conn->prepare("UPDATE activites SET type_activite = ?, description = ?, date_activite = ?, cout = ? WHERE id = ?");
        return $stmt->execute([$data['type_activite'], $data['description'], $data['date_activite'], $data['cout'], $id]);
    }

    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM activites WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
?>