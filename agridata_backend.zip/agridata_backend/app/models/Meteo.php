<?php
require_once __DIR__ . '/../../config/database.php';

class Meteo {
    private $conn;
    private $table = 'meteo';

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    public function getAll() {
        $stmt = $this->conn->prepare("SELECT * FROM meteo ORDER BY date DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find($id) {
        $stmt = $this->conn->prepare("SELECT * FROM meteo WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create($data) {
        $stmt = $this->conn->prepare("INSERT INTO meteo (parcelle_id, temperature, humidite, pluie_mm, vent, date) VALUES (?, ?, ?, ?, ?, ?)");
        return $stmt->execute([$data['parcelle_id'], $data['temperature'], $data['humidite'], $data['pluie_mm'], $data['vent'], $data['date']]);
    }

    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM meteo WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
?>