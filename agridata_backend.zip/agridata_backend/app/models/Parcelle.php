<?php
require_once __DIR__ . '/../../config/database.php';

class Parcelle {
    private $conn;
    private $table = 'parcelles';

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    public function getAll() {
        $stmt = $this->conn->prepare("
            SELECT * FROM parcelles 
            ORDER BY created_at DESC
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find($id) {
        $stmt = $this->conn->prepare("
            SELECT * FROM parcelles WHERE id = ?
        ");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create($data) {
        // ✅ Sécurisation des données
        $user_id     = $data['user_id']     ?? 1; // utilisateur par défaut
        $name        = $data['name']         ?? null;
        $superficie  = $data['superficie']   ?? 0;
        $localisation= $data['localisation']?? null;
        $type_sol    = $data['type_sol']     ?? null;

        $stmt = $this->conn->prepare("
            INSERT INTO parcelles 
            (user_id, name, superficie, localisation, type_sol)
            VALUES (?, ?, ?, ?, ?)
        ");

        return $stmt->execute([
            $user_id,
            $name,
            $superficie,
            $localisation,
            $type_sol
        ]);
    }

    public function update($id, $data) {
        $stmt = $this->conn->prepare("
            UPDATE parcelles 
            SET name = ?, superficie = ?, localisation = ?, type_sol = ?
            WHERE id = ?
        ");

        return $stmt->execute([
            $data['name'] ?? null,
            $data['superficie'] ?? 0,
            $data['localisation'] ?? null,
            $data['type_sol'] ?? null,
            $id
        ]);
    }

    public function delete($id) {
        $stmt = $this->conn->prepare("
            DELETE FROM parcelles WHERE id = ?
        ");
        return $stmt->execute([$id]);
    }
}
