<?php
require_once __DIR__ . '/../../config/database.php';

class Rapport {
    private $conn;
    private $table = 'rapports';

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    public function getAll() {
        $stmt = $this->conn->prepare("SELECT * FROM rapports ORDER BY date_generation DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find($id) {
        $stmt = $this->conn->prepare("SELECT * FROM rapports WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create($data) {
        $stmt = $this->conn->prepare("INSERT INTO rapports (user_id, titre, contenu, date_generation) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$data['user_id'], $data['titre'], $data['contenu'], $data['date_generation']]);
    }

    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM rapports WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
?>