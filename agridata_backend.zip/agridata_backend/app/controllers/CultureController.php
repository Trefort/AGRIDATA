<?php
require_once __DIR__ . '/../models/Culture.php';

class CultureController {

    public function index() {
        $m = new Culture();
        echo json_encode($m->getAll());
    }

    public function show() {
        $id = $_GET['id'] ?? null;
        if (!$id) { echo json_encode(['error'=>'id required']); return; }
        $m = new Culture();
        echo json_encode($m->find($id));
    }

    public function store() {
        $data = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $m = new Culture();
        $ok = $m->create($data);
        echo json_encode(['success' => (bool)$ok]);
    }

    public function update() {
        $id = $_GET['id'] ?? null;
        $data = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        if (!$id) { echo json_encode(['error'=>'id required']); return; }
        $m = new Culture();
        $ok = $m->update($id, $data);
        echo json_encode(['success' => (bool)$ok]);
    }

    public function delete() {
        $id = $_GET['id'] ?? null;
        if (!$id) { echo json_encode(['error'=>'id required']); return; }
        $m = new Culture();
        $ok = $m->delete($id);
        echo json_encode(['success' => (bool)$ok]);
    }
}
?>