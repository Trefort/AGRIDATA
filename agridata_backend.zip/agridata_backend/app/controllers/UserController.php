<?php
require_once __DIR__ . '/../models/User.php';

class UserController {

    public function index() {
        $model = new User();
        echo json_encode($model->getAll());
    }

    public function show() {
        $id = $_GET['id'] ?? null;
        if (!$id) {
            echo json_encode(['error' => 'id required']);
            return;
        }
        $model = new User();
        echo json_encode($model->find($id));
    }

    public function store() {
        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data) {
            $data = $_POST;
        }
        $model = new User();
        $ok = $model->create($data);
        echo json_encode(['success' => (bool)$ok]);
    }

    public function update() {
        $id = $_GET['id'] ?? null;
        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data) $data = $_POST;
        if (!$id) {
            echo json_encode(['error'=>'id required']);
            return;
        }
        $model = new User();
        $ok = $model->update($id, $data);
        echo json_encode(['success' => (bool)$ok]);
    }

    public function delete() {
        $id = $_GET['id'] ?? null;
        if (!$id) {
            echo json_encode(['error'=>'id required']);
            return;
        }
        $model = new User();
        $ok = $model->delete($id);
        echo json_encode(['success' => (bool)$ok]);
    }
}
?>